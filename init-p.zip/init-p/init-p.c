#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kprobes.h>

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("init kill protector");

static int protected_pid = 1;
module_param(protected_pid, int, 0644);

static unsigned long (*kallsyms_lookup_name_func)(const char *name);
static struct kprobe kp;

static const char *sys_kill_names[] = {
    "__x64_sys_kill",
    "__ia32_sys_kill",
    "__se_sys_kill",
    "__do_sys_kill",
    "sys_kill",
    NULL
};

static int handler_pre(struct kprobe *p, struct pt_regs *regs)
{
    int pid;

    if (regs->di >= 0xffff800000000000UL)
        pid = ((struct pt_regs *)regs->di)->di;
    else
        pid = (int)regs->di;

    if (pid != protected_pid)
        return 0;

    unsigned long *stack = (unsigned long *)regs->sp;
    regs->ax = -EPERM;
    regs->ip = *stack;
    regs->sp += 8;
    return 1;
}

static int __init find_kallsyms(void)
{
    struct kprobe tmp = { .symbol_name = "kallsyms_lookup_name" };
    int ret = register_kprobe(&tmp);
    if (ret)
        return ret;
    kallsyms_lookup_name_func = (void *)tmp.addr;
    unregister_kprobe(&tmp);
    return 0;
}

static int __init init_mod(void)
{
    int ret = find_kallsyms();
    if (ret)
        return ret;

    unsigned long addr = 0;
    for (int i = 0; sys_kill_names[i]; i++) {
        addr = kallsyms_lookup_name_func(sys_kill_names[i]);
        if (addr)
            break;
    }
    if (!addr)
        return -ENOENT;

    kp.addr = (void *)addr;
    kp.pre_handler = handler_pre;
    ret = register_kprobe(&kp);
    if (ret)
        return ret;

    pr_info("init-p: protecting pid %d via kprobe at %ps\n", protected_pid, kp.addr);
    return 0;
}

static void __exit cleanup_mod(void)
{
    unregister_kprobe(&kp);
    pr_info("init-p: unloaded\n");
}

module_init(init_mod);
module_exit(cleanup_mod);
